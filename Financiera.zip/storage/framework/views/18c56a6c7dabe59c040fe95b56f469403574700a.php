<?php $__env->startSection('template_title'); ?>
<?php echo e($mypime->name ?? 'Show Mypime'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-4 container mt-3">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div style="display: flex; justify-content: space-between;" class="marco">
                <h3 class=""><i class="fa fa-users"><b></i> Consulta Cliente</h3></b>
                <div class="float-right">
                    <label style="font-weight: bolder; font-size: large;">Fecha Actual : <?php echo e(\Carbon\Carbon::now()->format('m/d/Y')); ?></label>
                </div>
            </div>
            <div class="card">
                <div class="card-header" style="border-top: solid 4px green;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Información de Cliente')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('mypimes.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                            <div class="form-group">
                                <strong>Nombre:</strong>
                                <?php echo e($mypime->nombre); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dni:</strong>
                                <?php echo e($mypime->dni); ?>

                            </div>
                            <div class="form-group">
                                <strong>Rtn:</strong>
                                <?php echo e($mypime->rtn); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Cel:</strong>
                                <?php echo e($mypime->tel_cel); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Casa:</strong>
                                <?php echo e($mypime->tel_casa); ?>

                            </div>
                        </div>

                        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                            <div class="form-group">
                                <strong>Tel Tra:</strong>
                                <?php echo e($mypime->tel_tra); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dir Mypime:</strong>
                                <?php echo e($mypime->dir_mypime); ?>

                            </div>
                            <div class="form-group">
                                <strong>Fecha Nac:</strong>
                                <?php echo e($mypime->fecha_nac); ?>

                            </div>
                            <div class="form-group">
                                <strong>Ciudad:</strong>
                                <?php echo e($mypime->ciudad); ?>

                            </div>
                            <div class="form-group">
                                <strong>Correo:</strong>
                                <?php echo e($mypime->correo); ?>

                            </div>
                        </div>

                        <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                            <div class="form-group">
                                <strong>Foto:</strong>
                                <?php echo e($mypime->foto); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/mypime/show.blade.php ENDPATH**/ ?>