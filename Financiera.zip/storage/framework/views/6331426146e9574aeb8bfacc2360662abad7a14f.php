<div class="box box-info padding-1">
    <div class="box-body">

        <div class="row">
            <h4 style="font-weight: bold;">Información Cliente</h4>
            <hr>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <div class="form-group">
                    <?php echo e(Form::label('nombre')); ?>

                    <?php echo e(Form::text('nombre', $hipotecario->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dni')); ?>

                    <?php echo e(Form::number('dni', $hipotecario->dni, ['class' => 'form-control' . ($errors->has('dni') ? ' is-invalid' : ''), 'placeholder' => 'Dni'])); ?>

                    <?php echo $errors->first('dni', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('rtn')); ?>

                    <?php echo e(Form::number('rtn', $hipotecario->rtn, ['class' => 'form-control' . ($errors->has('rtn') ? ' is-invalid' : ''), 'placeholder' => 'Rtn'])); ?>

                    <?php echo $errors->first('rtn', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_cel')); ?>

                    <?php echo e(Form::number('tel_cel', $hipotecario->tel_cel, ['class' => 'form-control' . ($errors->has('tel_cel') ? ' is-invalid' : ''), 'placeholder' => 'Tel Cel'])); ?>

                    <?php echo $errors->first('tel_cel', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_casa')); ?>

                    <?php echo e(Form::number('tel_casa', $hipotecario->tel_casa, ['class' => 'form-control' . ($errors->has('tel_casa') ? ' is-invalid' : ''), 'placeholder' => 'Tel Casa'])); ?>

                    <?php echo $errors->first('tel_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_tra')); ?>

                    <?php echo e(Form::number('tel_tra', $hipotecario->tel_tra, ['class' => 'form-control' . ($errors->has('tel_tra') ? ' is-invalid' : ''), 'placeholder' => 'Tel Tra'])); ?>

                    <?php echo $errors->first('tel_tra', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('fecha_nac')); ?>

                    <?php echo e(Form::date('fecha_nac', $hipotecario->fecha_nac, ['class' => 'form-control' . ($errors->has('fecha_nac') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nac'])); ?>

                    <?php echo $errors->first('fecha_nac', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('ciudad')); ?>

                    <?php echo e(Form::text('ciudad', $hipotecario->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

                    <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('correo')); ?>

                    <?php echo e(Form::email('correo', $hipotecario->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

                    <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <!-- foto cliente -->
                <div class="form-group">
                    <label for="foto">Fotografía Cliente</label>
                    <input type="file" name="foto" class="form-control" id="foto">
                </div>
            </div>

            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <div class="form-group">
                    <?php echo e(Form::label('dir_casa')); ?>

                    <?php echo e(Form::textarea('dir_casa', $hipotecario->dir_casa, ['class' => 'form-control' . ($errors->has('dir_casa') ? ' is-invalid' : ''), 'placeholder' => 'Dir Casa'])); ?>

                    <?php echo $errors->first('dir_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_trabajo')); ?>

                    <?php echo e(Form::textarea('dir_trabajo', $hipotecario->dir_trabajo, ['class' => 'form-control' . ($errors->has('dir_trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Dir Trabajo'])); ?>

                    <?php echo $errors->first('dir_trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>

            <h4 class="mt-5" style="font-weight: bold;">Información Inmueble</h4>
            <hr>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <div class="form-group">
                    <?php echo e(Form::label('desc_inmueble')); ?>

                    <?php echo e(Form::textarea('desc_inmueble', $hipotecario->desc_inmueble, ['class' => 'form-control' . ($errors->has('desc_inmueble') ? ' is-invalid' : ''), 'placeholder' => 'Desc Inmueble'])); ?>

                    <?php echo $errors->first('desc_inmueble', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_inmueble')); ?>

                    <?php echo e(Form::textarea('dir_inmueble', $hipotecario->dir_inmueble, ['class' => 'form-control' . ($errors->has('dir_inmueble') ? ' is-invalid' : ''), 'placeholder' => 'Dir Inmueble'])); ?>

                    <?php echo $errors->first('dir_inmueble', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>

            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <!-- foto inmueble -->
                <div class="form-group">
                    <label for="foto_inmueble">Fotografía Inmueble</label>
                    <input type="file" name="foto_inmueble" class="form-control" id="foto_inmueble">
                </div>
            </div>
        </div>
    </div>

</div>
<!-- botones -->
<hr style="margin-top: 40px;">
    <div class="box-footer mt20 text-center">
        <button type="submit" class="btn btn-primary mt-3"><i class="fa fa-save" style="margin-right: 3px;"></i> Guardar</button>
    </div>
<!-- <div class="box-footer mt20">
    <button type="submit" class="btn btn-primary">Submit</button>
</div> -->
</div><?php /**PATH C:\wamp64\www\Financiera\resources\views/hipotecario/form.blade.php ENDPATH**/ ?>