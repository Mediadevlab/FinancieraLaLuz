<?php $__env->startSection('template_title'); ?>
Mypime
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div style="display: flex; justify-content: space-between;" class="marco">
        <h3 class=""><i class="fa fa-users"><b></i> Reporte de Clientes Préstamos Mypimes</h3></b>
        <div class="float-right">
            <label style="font-weight: bolder; font-size: large;">Fecha Actual : <?php echo e(\Carbon\Carbon::now()->format('m/d/Y')); ?></label>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2" style="border-top: solid 4px #344966;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            <?php echo e(__('Mypime')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('mypimes.create')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-plus"></i><?php echo e(__(' Generar Cliente Mypime')); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-hover mt-3" style="width: 100%;">
                            <thead class="thead text-center" style="background-color: #344966; color:white;">
                                <tr>
                                    <th>#</th>

                                    <th>Nombre</th>
                                    <th>Dni</th>
                                    <th>Ciudad</th>
                                    <th>Correo</th>
                                    <th>Foto</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mypimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mypime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td><?php echo e(++$i); ?></td>

                                    <td><?php echo e($mypime->nombre); ?></td>
                                    <td><?php echo e($mypime->dni); ?></td>
                                    <td><?php echo e($mypime->ciudad); ?></td>
                                    <td><?php echo e($mypime->correo); ?></td>
                                    <td>
                                    <img src="<?php echo e(asset( $mypime->foto )); ?>" alt="" class="img-fluid img-thumbnail" width="100px">
                                    </td>

                                    <td>
                                        <form action="<?php echo e(route('mypimes.destroy',$mypime->id)); ?>" method="POST" enctype="multipart/form-data" style="display: inline-block;" onsubmit="return confirm('¿Esta seguro que desea eliminar?')">
                                            <a class="btn btn-sm btn-primary " href="<?php echo e(route('mypimes.show',$mypime->id)); ?>"><i class="fa fa-fw fa-eye"></i></a>
                                            <a class="btn btn-sm btn-success" href="<?php echo e(route('mypimes.edit',$mypime->id)); ?>"><i class="fa fa-fw fa-edit"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo $mypimes->links(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/mypime/index.blade.php ENDPATH**/ ?>