<?php $__env->startSection('template_title'); ?>
Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    
    <div style="display: flex; justify-content: space-between;" class="marco2">
        <h3 class=""><i class="fa fa-users"><b></i> Reporte de Roles</h3></b>
        <div class="float-right">
            <label style="font-weight: bolder; font-size: large;">Fecha Actual : <?php echo e(\Carbon\Carbon::now()->format('m/d/Y')); ?></label>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2" style="border-top: solid 4px #344966;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">

                        <span id="card_title">
                            <?php echo e(__('Listado de Roles')); ?>

                        </span>

                        <div class="float-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <?php endif; ?>
                                <i class="fa fa-plus"></i><?php echo e(__(' Crear Rol')); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="mt-3 table table-striped table-hover" style="width: 100%;">
                            <thead class="thead" style="background-color: #344966; color:white;">
                                <tr class="align-middle">
                                    <th>#</th>

                                    <th>Nombre</th>
                                    <th>Origen</th>
                                    <th>Fecha de Creación</th>
                                    <th>Hora de Creación</th>
                                    <th>Permisos</th>

                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td><?php echo e(++$i); ?></td>

                                    <td><?php echo e($role->name); ?></td>
                                    <td><?php echo e($role->guard_name); ?></td>
                                    <td><?php echo e(date('d-m-y',strtotime($role->created_at))); ?></td>
                                    <td><?php echo e(date('H:i:s',strtotime($role->created_at))); ?></td>
                                    <td>
                                        <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge bg-info"><?php echo e($permission->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span class="badge bg-danger">Sin Permisos asignados</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_destroy')): ?>
                                        <form action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('¿Esta seguro que desea eliminar?')">
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_show')): ?>
                                            <a class="btn btn-sm btn-primary " href="<?php echo e(route('roles.show',$role->id)); ?>"><i class="fa fa-fw fa-eye"></i></a>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>
                                            <a class="btn btn-sm btn-success" href="<?php echo e(route('roles.edit',$role->id)); ?>"><i class="fa fa-fw fa-edit"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i></button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- <?php echo $roles->links(); ?> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/role/index.blade.php ENDPATH**/ ?>