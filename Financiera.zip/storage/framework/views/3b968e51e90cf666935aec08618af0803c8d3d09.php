<div class="box box-info padding-1">
    <div class="box-body">

        <div class="row">
            <h4 style="font-weight: bold;">Información Empleado</h4>
            <hr>
            <div class="form-group">
                <?php echo e(Form::label('nombre')); ?>

                <?php echo e(Form::text('nombre', $empleado->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('dni')); ?>

                <?php echo e(Form::number('dni', $empleado->dni, ['class' => 'form-control' . ($errors->has('dni') ? ' is-invalid' : ''), 'placeholder' => 'Dni'])); ?>

                <?php echo $errors->first('dni', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('cargo')); ?>

                <?php echo e(Form::text('cargo', $empleado->cargo, ['class' => 'form-control' . ($errors->has('cargo') ? ' is-invalid' : ''), 'placeholder' => 'Cargo'])); ?>

                <?php echo $errors->first('cargo', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('direccion')); ?>

                <?php echo e(Form::textarea('direccion', $empleado->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

                <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('telefono')); ?>

                <?php echo e(Form::number('telefono', $empleado->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

                <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

            </div>
            <div class="form-group">
                <label for="estatus">Estatus</label>
                <select class="form-control" name="estatus" id="">
                    <option selected>Activo</option>
                    <option value="Inactivo">Inactivo</option>
                </select>
            </div>

            <div class="form-group">
                <label for="foto_emp">Fotografía Empleado</label>
                <input type="file" name="foto_emp" class="form-control" id="foto_emp">
            </div>
        </div>

    </div>

    <!-- botones -->
    <hr style="margin-top: 40px;">
    <div class="box-footer mt20 text-center">
        <button type="submit" class="btn btn-primary mt-3"><i class="fa fa-save" style="margin-right: 3px;"></i> Guardar</button>
    </div>
</div><?php /**PATH C:\wamp64\www\Financiera\resources\views/empleado/form.blade.php ENDPATH**/ ?>