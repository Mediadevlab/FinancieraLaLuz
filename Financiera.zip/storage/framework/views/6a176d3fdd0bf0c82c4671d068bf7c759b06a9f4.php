<?php $__env->startSection('template_title'); ?>
<?php echo e($permission->name ?? 'Show Permission'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content container-fluid">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Detalles de Permiso')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('permission.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="form-group">
                        <strong>Nombre:</strong>
                        <?php echo e($permission->name); ?>

                    </div>
                    <div class="form-group">
                        <strong>Origen:</strong>
                        <?php echo e($permission->guard_name); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/permission/show.blade.php ENDPATH**/ ?>