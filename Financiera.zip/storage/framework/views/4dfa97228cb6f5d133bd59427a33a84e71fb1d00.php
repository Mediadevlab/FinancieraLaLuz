<div class="box box-info padding-1">
    <div class="box-body">

        <div class="row">

            <!--Info Cliente-->

            <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                <div class="form-group">
                    <?php echo e(Form::label('Nombre')); ?>

                    <?php echo e(Form::text('nombre', $cliente->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('DNI')); ?>

                    <?php echo e(Form::number('dni', $cliente->dni, ['class' => 'form-control' . ($errors->has('dni') ? ' is-invalid' : ''), 'placeholder' => 'Dni'])); ?>

                    <?php echo $errors->first('dni', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('RTN')); ?>

                    <?php echo e(Form::number('rtn', $cliente->rtn, ['class' => 'form-control' . ($errors->has('rtn') ? ' is-invalid' : ''), 'placeholder' => 'Rtn'])); ?>

                    <?php echo $errors->first('rtn', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Teléfono')); ?>

                    <?php echo e(Form::number('telefono', $cliente->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

                    <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Trabajo')); ?>

                    <?php echo e(Form::text('trabajo', $cliente->trabajo, ['class' => 'form-control' . ($errors->has('trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Trabajo'])); ?>

                    <?php echo $errors->first('trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Teléfono de Trabajo')); ?>

                    <?php echo e(Form::number('tel_trabajo', $cliente->tel_trabajo, ['class' => 'form-control' . ($errors->has('tel_trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Tel Trabajo'])); ?>

                    <?php echo $errors->first('tel_trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Dirección')); ?>

                    <?php echo e(Form::text('direccion', $cliente->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

                    <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Dirección del Trabajo')); ?>

                    <?php echo e(Form::text('dir_trabajo', $cliente->dir_trabajo, ['class' => 'form-control' . ($errors->has('dir_trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Dir Trabajo'])); ?>

                    <?php echo $errors->first('dir_trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Fecha de Nacimiento')); ?>

                    <?php echo e(Form::date('fechaNac', $cliente->fechaNac, ['class' => 'form-control' . ($errors->has('fechaNac') ? ' is-invalid' : ''), 'placeholder' => 'Fechanac'])); ?>

                    <?php echo $errors->first('fechaNac', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <label for="estado">Estado</label>
                    <select class="form-control" name="estado" id="">
                        <option selected>Activo</option>
                        <option value="Inactivo">Inactivo</option>
                    </select>
                </div>
            </div>

            <!--Info Aval-->

            <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                <div class="form-group">
                    <?php echo e(Form::label('Nombre del Aval')); ?>

                    <?php echo e(Form::text('nom_aval', $cliente->nom_aval, ['class' => 'form-control' . ($errors->has('nom_aval') ? ' is-invalid' : ''), 'placeholder' => 'Nom Aval'])); ?>

                    <?php echo $errors->first('nom_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('DNI Aval')); ?>

                    <?php echo e(Form::number('dni_aval', $cliente->dni_aval, ['class' => 'form-control' . ($errors->has('dni_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dni Aval'])); ?>

                    <?php echo $errors->first('dni_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('RTN Aval')); ?>

                    <?php echo e(Form::number('rtn_aval', $cliente->rtn_aval, ['class' => 'form-control' . ($errors->has('rtn_aval') ? ' is-invalid' : ''), 'placeholder' => 'Rtn Aval'])); ?>

                    <?php echo $errors->first('rtn_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Correo Electrónico')); ?>

                    <?php echo e(Form::email('correo', $cliente->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

                    <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Dirección del Aval')); ?>

                    <?php echo e(Form::text('dir_aval', $cliente->dir_aval, ['class' => 'form-control' . ($errors->has('dir_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dir Aval'])); ?>

                    <?php echo $errors->first('dir_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Teléfono de Casa del Aval')); ?>

                    <?php echo e(Form::number('telCasa_aval', $cliente->telCasa_aval, ['class' => 'form-control' . ($errors->has('telCasa_aval') ? ' is-invalid' : ''), 'placeholder' => 'Tel casa Aval'])); ?>

                    <?php echo $errors->first('telCasa_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Dirección Trabajo del Aval')); ?>

                    <?php echo e(Form::text('dirTrabajo_aval', $cliente->dirTrabajo_aval, ['class' => 'form-control' . ($errors->has('dirTrabajo_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dirtrabajo Aval'])); ?>

                    <?php echo $errors->first('dirTrabajo_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Teléfono de Trabajo del Aval')); ?>

                    <?php echo e(Form::number('telTrabajo_aval', $cliente->telTrabajo_aval, ['class' => 'form-control' . ($errors->has('telTrabajo_aval') ? ' is-invalid' : ''), 'placeholder' => 'Teltrabajo Aval'])); ?>

                    <?php echo $errors->first('telTrabajo_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('Fecha de Nacimiento del Aval')); ?>

                    <?php echo e(Form::date('fechaNac_aval', $cliente->fechaNac_aval, ['class' => 'form-control' . ($errors->has('fechaNac_aval') ? ' is-invalid' : ''), 'placeholder' => 'Fechanac Aval'])); ?>

                    <?php echo $errors->first('fechaNac_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>

            <!--fotografias croquis casa y trabajo-->

            <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">

                <!-- foto cliente -->
                <div class="form-group">
                    <label for="foto_cliente">Fotografía Cliente</label>
                    <input type="file" name="foto_cliente" class="form-control" id="foto_cliente">
                </div>

                <br>
                <!-- foto casa -->
                <div class="form-group">
                    <label for="croquis_casa">Fotografía Croquis Casa</label>
                    <input type="file" name="croquis_casa" class="form-control" id="croquis_casa">
                </div>

                <br>
                <!-- foto trabajo -->
                <div class="form-group">
                    <label for="croquis_trabajo">Fotografía Croquis Trabajo</label>
                    <input type="file" name="croquis_trabajo" class="form-control" id="croquis_trabajo">
                </div>
                
            </div>
        </div>

    </div>
    <!-- botones -->
    <hr style="margin-top: 40px;">
    <div class="box-footer mt20 text-center">
        <button type="submit" class="btn btn-primary mt-3"><i class="fa fa-save" style="margin-right: 3px;"></i> Guardar</button>
    </div>

</div><?php /**PATH C:\wamp64\www\Financiera\resources\views/cliente/form.blade.php ENDPATH**/ ?>