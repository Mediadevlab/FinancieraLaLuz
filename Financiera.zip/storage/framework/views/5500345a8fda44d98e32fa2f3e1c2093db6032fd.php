<?php $__env->startSection('template_title'); ?>
<?php echo e($role->name ?? 'Show Role'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content container-fluid">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Vista de Rol')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="form-group">
                        <strong>Nombre del Rol:</strong>
                        <?php echo e($role->name); ?>

                    </div>
                    <div class="form-group">
                        <strong>Sector de creación:</strong>
                        <?php echo e($role->guard_name); ?>

                    </div>
                    <div class="form-group">
                        <strong>Fecha de creación:</strong>
                        <?php echo e(date('d-m-y',strtotime($role->created_at))); ?>

                    </div>
                    <div class="form-group">
                        <strong>Hora de creación:</strong>
                        <?php echo e(date('H:i:s',strtotime($role->created_at))); ?>

                    </div>
                    <div class="form-group">
                        <strong>Permisos asignados:</strong>
                        <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="badge bg-info"><?php echo e($permission->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="badge bg-danger">Sin permisos asignados</span>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/role/show.blade.php ENDPATH**/ ?>