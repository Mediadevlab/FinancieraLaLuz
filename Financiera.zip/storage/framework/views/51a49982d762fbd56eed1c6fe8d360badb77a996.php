<div class="box box-info padding-1">
    <div class="box-body">

        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <h4 style="font-weight: bold;">Información Cliente</h4>
                <hr>

                <div class="form-group">
                    <?php echo e(Form::label('nombre completo')); ?>

                    <?php echo e(Form::text('nombre', $prendario->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('DNI')); ?>

                    <?php echo e(Form::number('dni', $prendario->dni, ['class' => 'form-control' . ($errors->has('dni') ? ' is-invalid' : ''), 'placeholder' => 'Dni'])); ?>

                    <?php echo $errors->first('dni', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('RTN')); ?>

                    <?php echo e(Form::number('rtn', $prendario->rtn, ['class' => 'form-control' . ($errors->has('rtn') ? ' is-invalid' : ''), 'placeholder' => 'Rtn'])); ?>

                    <?php echo $errors->first('rtn', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('celular')); ?>

                    <?php echo e(Form::number('tel_cel', $prendario->tel_cel, ['class' => 'form-control' . ($errors->has('tel_cel') ? ' is-invalid' : ''), 'placeholder' => 'Tel Cel'])); ?>

                    <?php echo $errors->first('tel_cel', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('teléfono_casa')); ?>

                    <?php echo e(Form::number('tel_casa', $prendario->tel_casa, ['class' => 'form-control' . ($errors->has('tel_casa') ? ' is-invalid' : ''), 'placeholder' => 'Tel Casa'])); ?>

                    <?php echo $errors->first('tel_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('teléfono_trabajo')); ?>

                    <?php echo e(Form::number('tel_tra', $prendario->tel_tra, ['class' => 'form-control' . ($errors->has('tel_tra') ? ' is-invalid' : ''), 'placeholder' => 'Tel Tra'])); ?>

                    <?php echo $errors->first('tel_tra', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dirección_casa')); ?>

                    <?php echo e(Form::textarea('dir_casa', $prendario->dir_casa, ['class' => 'form-control' . ($errors->has('dir_casa') ? ' is-invalid' : ''), 'placeholder' => 'Dir Casa'])); ?>

                    <?php echo $errors->first('dir_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('dirección_trabajo')); ?>

                    <?php echo e(Form::textarea('dir_trabajo', $prendario->dir_trabajo, ['class' => 'form-control' . ($errors->has('dir_trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Dir Trabajo'])); ?>

                    <?php echo $errors->first('dir_trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('fecha_nacimiento')); ?>

                    <?php echo e(Form::date('fecha_nac', $prendario->fecha_nac, ['class' => 'form-control' . ($errors->has('fecha_nac') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nac'])); ?>

                    <?php echo $errors->first('fecha_nac', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('ciudad')); ?>

                    <?php echo e(Form::text('ciudad', $prendario->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

                    <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('correo')); ?>

                    <?php echo e(Form::email('correo', $prendario->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

                    <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <!-- foto cliente -->
                <div class="form-group">
                    <label for="foto">Fotografía Cliente</label>
                    <input type="file" name="foto" class="form-control" id="foto">
                </div>
            </div>

            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <h4 style="font-weight: bold;">Información Vehículo</h4>
                <hr>
                <div class="form-group">
                    <?php echo e(Form::label('descripción_vehículo')); ?>

                    <?php echo e(Form::textarea('desc_vehiculo', $prendario->desc_vehiculo, ['class' => 'form-control' . ($errors->has('desc_vehiculo') ? ' is-invalid' : ''), 'placeholder' => 'Desc Vehiculo'])); ?>

                    <?php echo $errors->first('desc_vehiculo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('placa')); ?>

                    <?php echo e(Form::number('placa', $prendario->placa, ['class' => 'form-control' . ($errors->has('placa') ? ' is-invalid' : ''), 'placeholder' => 'Placa'])); ?>

                    <?php echo $errors->first('placa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('color')); ?>

                    <?php echo e(Form::text('color', $prendario->color, ['class' => 'form-control' . ($errors->has('color') ? ' is-invalid' : ''), 'placeholder' => 'Color'])); ?>

                    <?php echo $errors->first('color', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('modelo')); ?>

                    <?php echo e(Form::text('modelo', $prendario->modelo, ['class' => 'form-control' . ($errors->has('modelo') ? ' is-invalid' : ''), 'placeholder' => 'Modelo'])); ?>

                    <?php echo $errors->first('modelo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('marca')); ?>

                    <?php echo e(Form::text('marca', $prendario->marca, ['class' => 'form-control' . ($errors->has('marca') ? ' is-invalid' : ''), 'placeholder' => 'Marca'])); ?>

                    <?php echo $errors->first('marca', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('año')); ?>

                    <?php echo e(Form::number('anio', $prendario->anio, ['class' => 'form-control' . ($errors->has('anio') ? ' is-invalid' : ''), 'placeholder' => 'Anio'])); ?>

                    <?php echo $errors->first('anio', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('documentación')); ?>

                    <?php echo e(Form::textarea('documentacion', $prendario->documentacion, ['class' => 'form-control' . ($errors->has('documentacion') ? ' is-invalid' : ''), 'placeholder' => 'Documentacion'])); ?>

                    <?php echo $errors->first('documentacion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <!-- foto vehiculo -->
                <div class="form-group">
                    <label for="foto_vehiculo">Fotografía Vehículo</label>
                    <input type="file" name="foto_vehiculo" class="form-control" id="foto_vehiculo">
                </div>
            </div>


        </div>
    </div>

</div>
<!-- botones -->
<hr style="margin-top: 40px;">
<div class="box-footer mt20 text-center">
    <button type="submit" class="btn btn-primary mt-3"><i class="fa fa-save" style="margin-right: 3px;"></i> Guardar</button>
</div>
<!-- <div class="box-footer mt20">
    <button type="submit" class="btn btn-primary">Submit</button>
</div> -->
</div><?php /**PATH C:\wamp64\www\Financiera\resources\views/prendario/form.blade.php ENDPATH**/ ?>