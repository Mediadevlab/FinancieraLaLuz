<div class="box box-info padding-1">
    <div class="box-body">

        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <h4 style="font-weight: bold;">Información Cliente</h4>
                <hr>
                <div class="form-group">
                    <?php echo e(Form::label('código de préstamo')); ?>

                    <?php echo e(Form::text('prestamo_id ', $fiduciario->prestamo_id , ['class' => 'form-control' . ($errors->has('prestamo_id ') ? ' is-invalid' : ''), 'placeholder' => 'código de préstamo'])); ?>

                    <?php echo $errors->first('prestamo_id ', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('nombre')); ?>

                    <?php echo e(Form::text('nombre', $fiduciario->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

                    <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dni')); ?>

                    <?php echo e(Form::number('dni', $fiduciario->dni, ['class' => 'form-control' . ($errors->has('dni') ? ' is-invalid' : ''), 'placeholder' => 'Dni'])); ?>

                    <?php echo $errors->first('dni', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('rtn')); ?>

                    <?php echo e(Form::number('rtn', $fiduciario->rtn, ['class' => 'form-control' . ($errors->has('rtn') ? ' is-invalid' : ''), 'placeholder' => 'Rtn'])); ?>

                    <?php echo $errors->first('rtn', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_cel')); ?>

                    <?php echo e(Form::number('tel_cel', $fiduciario->tel_cel, ['class' => 'form-control' . ($errors->has('tel_cel') ? ' is-invalid' : ''), 'placeholder' => 'Tel Cel'])); ?>

                    <?php echo $errors->first('tel_cel', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_casa')); ?>

                    <?php echo e(Form::number('tel_casa', $fiduciario->tel_casa, ['class' => 'form-control' . ($errors->has('tel_casa') ? ' is-invalid' : ''), 'placeholder' => 'Tel Casa'])); ?>

                    <?php echo $errors->first('tel_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_tra')); ?>

                    <?php echo e(Form::number('tel_tra', $fiduciario->tel_tra, ['class' => 'form-control' . ($errors->has('tel_tra') ? ' is-invalid' : ''), 'placeholder' => 'Tel Tra'])); ?>

                    <?php echo $errors->first('tel_tra', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_casa')); ?>

                    <?php echo e(Form::textarea('dir_casa', $fiduciario->dir_casa, ['class' => 'form-control' . ($errors->has('dir_casa') ? ' is-invalid' : ''), 'placeholder' => 'Dir Casa'])); ?>

                    <?php echo $errors->first('dir_casa', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_trabajo')); ?>

                    <?php echo e(Form::textarea('dir_trabajo', $fiduciario->dir_trabajo, ['class' => 'form-control' . ($errors->has('dir_trabajo') ? ' is-invalid' : ''), 'placeholder' => 'Dir Trabajo'])); ?>

                    <?php echo $errors->first('dir_trabajo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('fecha_nac')); ?>

                    <?php echo e(Form::date('fecha_nac', $fiduciario->fecha_nac, ['class' => 'form-control' . ($errors->has('fecha_nac') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nac'])); ?>

                    <?php echo $errors->first('fecha_nac', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('ciudad')); ?>

                    <?php echo e(Form::text('ciudad', $fiduciario->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

                    <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('correo')); ?>

                    <?php echo e(Form::email('correo', $fiduciario->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

                    <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <!-- foto cliente -->
                <div class="form-group">
                    <label for="foto">Fotografía Cliente</label>
                    <input type="file" name="foto" class="form-control" id="foto">
                </div>

            </div>

            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                <h4 style="font-weight: bold;">Información Aval</h4>
                <hr>
                <div class="form-group">
                    <?php echo e(Form::label('nombre_aval')); ?>

                    <?php echo e(Form::text('nombre_aval', $fiduciario->nombre_aval, ['class' => 'form-control' . ($errors->has('nombre_aval') ? ' is-invalid' : ''), 'placeholder' => 'Nombre Aval'])); ?>

                    <?php echo $errors->first('nombre_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dni_aval')); ?>

                    <?php echo e(Form::number('dni_aval', $fiduciario->dni_aval, ['class' => 'form-control' . ($errors->has('dni_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dni Aval'])); ?>

                    <?php echo $errors->first('dni_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('rtn_aval')); ?>

                    <?php echo e(Form::number('rtn_aval', $fiduciario->rtn_aval, ['class' => 'form-control' . ($errors->has('rtn_aval') ? ' is-invalid' : ''), 'placeholder' => 'Rtn Aval'])); ?>

                    <?php echo $errors->first('rtn_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_cel_aval')); ?>

                    <?php echo e(Form::number('tel_cel_aval', $fiduciario->tel_cel_aval, ['class' => 'form-control' . ($errors->has('tel_cel_aval') ? ' is-invalid' : ''), 'placeholder' => 'Tel Cel Aval'])); ?>

                    <?php echo $errors->first('tel_cel_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_casa_aval')); ?>

                    <?php echo e(Form::number('tel_casa_aval', $fiduciario->tel_casa_aval, ['class' => 'form-control' . ($errors->has('tel_casa_aval') ? ' is-invalid' : ''), 'placeholder' => 'Tel Casa Aval'])); ?>

                    <?php echo $errors->first('tel_casa_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('tel_tra_aval')); ?>

                    <?php echo e(Form::number('tel_tra_aval', $fiduciario->tel_tra_aval, ['class' => 'form-control' . ($errors->has('tel_tra_aval') ? ' is-invalid' : ''), 'placeholder' => 'Tel Tra Aval'])); ?>

                    <?php echo $errors->first('tel_tra_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_casa_aval')); ?>

                    <?php echo e(Form::textarea('dir_casa_aval', $fiduciario->dir_casa_aval, ['class' => 'form-control' . ($errors->has('dir_casa_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dir Casa Aval'])); ?>

                    <?php echo $errors->first('dir_casa_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('dir_trabajo_aval')); ?>

                    <?php echo e(Form::textarea('dir_trabajo_aval', $fiduciario->dir_trabajo_aval, ['class' => 'form-control' . ($errors->has('dir_trabajo_aval') ? ' is-invalid' : ''), 'placeholder' => 'Dir Trabajo Aval'])); ?>

                    <?php echo $errors->first('dir_trabajo_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('fecha_nac_aval')); ?>

                    <?php echo e(Form::date('fecha_nac_aval', $fiduciario->fecha_nac_aval, ['class' => 'form-control' . ($errors->has('fecha_nac_aval') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nac Aval'])); ?>

                    <?php echo $errors->first('fecha_nac_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('ciudad_aval')); ?>

                    <?php echo e(Form::text('ciudad_aval', $fiduciario->ciudad_aval, ['class' => 'form-control' . ($errors->has('ciudad_aval') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad Aval'])); ?>

                    <?php echo $errors->first('ciudad_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('correo_aval')); ?>

                    <?php echo e(Form::email('correo_aval', $fiduciario->correo_aval, ['class' => 'form-control' . ($errors->has('correo_aval') ? ' is-invalid' : ''), 'placeholder' => 'Correo Aval'])); ?>

                    <?php echo $errors->first('correo_aval', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
                <!-- foto cliente -->
                <div class="form-group">
                    <label for="foto_aval">Fotografía Aval</label>
                    <input type="file" name="foto_aval" class="form-control" id="foto_aval">
                </div>
            </div>

        </div>

    </div>
    <!-- botones -->
    <hr style="margin-top: 40px;">
    <div class="box-footer mt20 text-center">
        <button type="submit" class="btn btn-primary mt-3"><i class="fa fa-save" style="margin-right: 3px;"></i> Guardar</button>
    </div>
    <!-- <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div> -->
</div><?php /**PATH C:\wamp64\www\Financiera\resources\views/fiduciario/form.blade.php ENDPATH**/ ?>