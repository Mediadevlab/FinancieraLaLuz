<?php $__env->startSection('template_title'); ?>
<?php echo e($prendario->name ?? 'Show Prendario'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-4 container mt-3">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div style="display: flex; justify-content: space-between;" class="marco">
                <h3 class=""><i class="fa fa-users"><b></i> Consulta Cliente y Vehículo</h3></b>
                <div class="float-right">
                    <label style="font-weight: bolder; font-size: large;">Fecha Actual : <?php echo e(\Carbon\Carbon::now()->format('m/d/Y')); ?></label>
                </div>
            </div>

            <div class="card">
                <div class="card-header" style="border-top: solid 4px green;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Información de Cliente y Vehículo')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('prendarios.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h4>Datos Cliente</h4>
                            <hr>
                            <div class="form-group">
                                <strong>Nombre Completo:</strong>
                                <?php echo e($prendario->nombre); ?>

                            </div>
                            <div class="form-group">
                                <strong>DNI:</strong>
                                <?php echo e($prendario->dni); ?>

                            </div>
                            <div class="form-group">
                                <strong>RTN:</strong>
                                <?php echo e($prendario->rtn); ?>

                            </div>
                            <div class="form-group">
                                <strong>Celular:</strong>
                                <?php echo e($prendario->tel_cel); ?>

                            </div>
                            <div class="form-group">
                                <strong>Teléfono Casa:</strong>
                                <?php echo e($prendario->tel_casa); ?>

                            </div>
                            <div class="form-group">
                                <strong>Teléfono Trabajo:</strong>
                                <?php echo e($prendario->tel_tra); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dirección Casa:</strong>
                                <?php echo e($prendario->dir_casa); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dirección Trabajo:</strong>
                                <?php echo e($prendario->dir_trabajo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Fecha Nacimiento:</strong>
                                <?php echo e($prendario->fecha_nac); ?>

                            </div>
                            <div class="form-group">
                                <strong>Ciudad:</strong>
                                <?php echo e($prendario->ciudad); ?>

                            </div>
                            <div class="form-group">
                                <strong>Correo:</strong>
                                <?php echo e($prendario->correo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Foto:</strong>
                                <?php echo e($prendario->foto); ?>

                            </div>
                        </div>

                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h4>Datos Vehículo</h4>
                            <hr>
                            <div class="form-group">
                                <strong>Descripción Vehiculo:</strong>
                                <?php echo e($prendario->desc_vehiculo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Placa:</strong>
                                <?php echo e($prendario->placa); ?>

                            </div>
                            <div class="form-group">
                                <strong>Color:</strong>
                                <?php echo e($prendario->color); ?>

                            </div>
                            <div class="form-group">
                                <strong>Modelo:</strong>
                                <?php echo e($prendario->modelo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Marca:</strong>
                                <?php echo e($prendario->marca); ?>

                            </div>
                            <div class="form-group">
                                <strong>Año:</strong>
                                <?php echo e($prendario->anio); ?>

                            </div>
                            <div class="form-group">
                                <strong>Documentación:</strong>
                                <?php echo e($prendario->documentacion); ?>

                            </div>
                            <div class="form-group">
                                <strong>Foto Vehículo:</strong>
                                <?php echo e($prendario->foto_vehiculo); ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/prendario/show.blade.php ENDPATH**/ ?>