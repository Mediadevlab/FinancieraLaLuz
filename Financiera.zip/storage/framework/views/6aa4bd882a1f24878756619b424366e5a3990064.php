<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row justify-content-left">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2" style="font-weight: bold; font-size:large;"><i class="fa fa-list-ol" style="margin-right: 8px;"></i><?php echo e(__('Métricas')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">


                        <!-- tarjeta fiducario -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Préstamos Fiduciarios')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('fiduciarios.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    use App\Models\Fiduciario;
                                    $cant_fiduciario = Fiduciario::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_fiduciario); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta hipotecario -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Préstamos Hipotecarios')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('hipotecarios.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    use App\Models\Hipotecario;
                                    $cant_hipotecario = Hipotecario::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_hipotecario); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta prendario -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Préstamos Prendarios')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('prendarios.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    use App\Models\Prendario;
                                    $cant_prendario = Prendario::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_prendario); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta mypime -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Préstamos Mypimes')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('mypimes.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    use App\Models\Mypime;
                                    $cant_mypime = Mypime::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_mypime); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta usuarios -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Usuarios')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('users.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    use App\Models\User;
                                    $cant_usuarios = User::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_usuarios); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta roles -->
                        <!-- <div class="col-sm-3">
                            <div class="card">
                                <div class="card-body d-grid gap-2">
                                
                                    <?php
                                    use Spatie\Permission\Models\Role;
                                    $cant_roles = Role::count();
                                    ?>
                                    <h4 class="text-center"><strong>Roles </strong><span class="badge bg-danger"><?php echo e($cant_roles); ?></span></h4>
                                    <a href="/roles" class="btn btn-primary">Ver más</a>
                                </div>
                            </div>
                        </div> -->

                        <!-- tarjeta clientes -->
                        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                            <div class="card cajaPrestamos border-primary mb-3" style="max-width: 40rem;">
                                <div class="card-header text-center">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Clientes')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('clientes.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-3 text-primary">
                                    <?php
                                    use App\Models\Cliente;
                                    $cant_clientes = cliente::count();
                                    ?>

                                    <div class="text-center mb-2" style="font-size: x-large;">Existentes<span class="badge bg-danger" style="margin-left: 6px;"><?php echo e($cant_clientes); ?></span></div>
                                </div>
                            </div>
                        </div>

                        <!-- tarjeta capital -->
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <div class="card cajaPrestamos2 mb-3" style="max-width: 40rem;">
                                <div class="card-header">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Total de Capital')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('prestamos.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search" style="color: white;"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">
                                    <?php
                                    
                                    ?>

                                    <div style="font-weight: bolder; font-size:xx-large; color: white;" class="text-center mb-2">L<span class="badge bg-success" style="margin-left: 6px;"></span></div>

                                </div>
                            </div>
                        </div>

                        <!-- tarjeta interese -->
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <div class="card cajaPrestamos3 mb-3" style="max-width: 40rem;">
                                <div class="card-header">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span id="card_title">
                                            <?php echo e(__('Total de Interés')); ?>

                                        </span>

                                        <div class="float-right">
                                            <a href="<?php echo e(route('prestamos.index')); ?>" class="float-right" data-placement="left">
                                                <i class="fa fa-search" style="color: white;"></i>
                                                <!--<?php echo e(__(' Ver más')); ?>-->
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body d-grid gap-2 text-primary">

                                    <div style="font-weight: bolder; font-size:xx-large; color:white;" class="text-center mb-2">L<span class="badge bg-success" style="margin-left: 6px;"></span></div>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card cabecera1">
                <div class="card-header cabecera2" style="font-weight: bold; font-size:large;"><i class="fa fa-chart-line" style="margin-right: 8px;"></i><?php echo e(__('Estadíscas')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="row">

                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h5 class="text-center">Capital por Mes</h5>
                            <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                        </div>

                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h5 class="text-center">Préstamos por Mes</h5>
                            <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- script charts -->
<script type="text/javascript">
    var _ydata = JSON.parse('<?php echo json_encode($months); ?>');
    var _xdata = JSON.parse('<?php echo json_encode($monthCount); ?>');
</script>
<!-- <script type="text/javascript">
    var _Xdata = JSON.parse('<?php echo json_encode($months); ?>');
    var _Ydata = JSON.parse('<?php echo json_encode($monthCount); ?>');
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/home.blade.php ENDPATH**/ ?>