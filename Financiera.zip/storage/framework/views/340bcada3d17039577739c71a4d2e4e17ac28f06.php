<?php $__env->startSection('template_title'); ?>
<?php echo e($prestamo->name ?? 'Show Prestamo'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content container-fluid">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Información del Préstamo')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('prestamos.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="form-group">
                        <strong>Codigo:</strong>
                        <?php echo e($prestamo->codigo); ?>

                    </div>
                    <div class="form-group">
                        <strong>Tipo:</strong>
                        <?php echo e($prestamo->tipo); ?>

                    </div>
                    <div class="form-group">
                        <strong>Capital:</strong>
                        <?php echo e($prestamo->capital); ?>

                    </div>
                    <div class="form-group">
                        <strong>Tipo Tasa:</strong>
                        <?php echo e($prestamo->tipo_tasa); ?>

                    </div>
                    <div class="form-group">
                        <strong>Cuota:</strong>
                        <?php echo e($prestamo->cuota); ?>

                    </div>
                    <div class="form-group">
                        <strong>Forma Pago:</strong>
                        <?php echo e($prestamo->forma_pago); ?>

                    </div>
                    <div class="form-group">
                        <strong>Fecha Solicitud:</strong>
                        <?php echo e($prestamo->fecha_solicitud); ?>

                    </div>
                    <div class="form-group">
                        <strong>Fecha Inicio:</strong>
                        <?php echo e($prestamo->fecha_inicio); ?>

                    </div>
                    <div class="form-group">
                        <strong>Fecha Fin:</strong>
                        <?php echo e($prestamo->fecha_fin); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/prestamo/show.blade.php ENDPATH**/ ?>