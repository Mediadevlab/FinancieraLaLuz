<?php $__env->startSection('template_title'); ?>
    <?php echo e($comision->name ?? 'Show Comision'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Detalle Comisiones')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('comisiones.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Pago:</strong>
                            <?php echo e($comision->pago); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/comision/show.blade.php ENDPATH**/ ?>