<?php $__env->startSection('template_title'); ?>
<?php echo e($fiduciario->name ?? 'Show Fiduciario'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-4 container mt-3">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div style="display: flex; justify-content: space-between;" class="marco">
                <h3 class=""><i class="fa fa-users"><b></i> Consulta Cliente y Aval</h3></b>
                <div class="float-right">
                    <label style="font-weight: bolder; font-size: large;">Fecha Actual : <?php echo e(\Carbon\Carbon::now()->format('m/d/Y')); ?></label>
                </div>
            </div>

            <div class="card">
                <div class="card-header" style="border-top: solid 4px green;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <?php echo e(__('Información de Cliente y del Aval')); ?>

                        </span>

                        <div class="float-right">
                            <a href="<?php echo e(route('fiduciarios.index')); ?>" class="btn btn-primary btn-sm float-right" data-placement="left">
                                <i class="fa fa-chevron-left"></i><?php echo e(__(' Volver')); ?>

                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h4>Datos Cliente</h4>
                            <hr>
                            <div class="form-group">
                                <strong>Nombre:</strong>
                                <?php echo e($fiduciario->nombre); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dni:</strong>
                                <?php echo e($fiduciario->dni); ?>

                            </div>
                            <div class="form-group">
                                <strong>Rtn:</strong>
                                <?php echo e($fiduciario->rtn); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Cel:</strong>
                                <?php echo e($fiduciario->tel_cel); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Casa:</strong>
                                <?php echo e($fiduciario->tel_casa); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Tra:</strong>
                                <?php echo e($fiduciario->tel_tra); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dir Casa:</strong>
                                <?php echo e($fiduciario->dir_casa); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dir Trabajo:</strong>
                                <?php echo e($fiduciario->dir_trabajo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Fecha Nac:</strong>
                                <?php echo e($fiduciario->fecha_nac); ?>

                            </div>
                            <div class="form-group">
                                <strong>Ciudad:</strong>
                                <?php echo e($fiduciario->ciudad); ?>

                            </div>
                            <div class="form-group">
                                <strong>Correo:</strong>
                                <?php echo e($fiduciario->correo); ?>

                            </div>
                            <div class="form-group">
                                <strong>Foto:</strong>
                                <?php echo e($fiduciario->foto); ?>

                            </div>
                        </div>

                        <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
                            <h4>Datos Aval</h4>
                            <hr>
                            <div class="form-group">
                                <strong>Nombre Aval:</strong>
                                <?php echo e($fiduciario->nombre_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dni Aval:</strong>
                                <?php echo e($fiduciario->dni_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Rtn Aval:</strong>
                                <?php echo e($fiduciario->rtn_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Cel Aval:</strong>
                                <?php echo e($fiduciario->tel_cel_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Casa Aval:</strong>
                                <?php echo e($fiduciario->tel_casa_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Tel Tra Aval:</strong>
                                <?php echo e($fiduciario->tel_tra_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dir Casa Aval:</strong>
                                <?php echo e($fiduciario->dir_casa_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Dir Trabajo Aval:</strong>
                                <?php echo e($fiduciario->dir_trabajo_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Fecha Nac Aval:</strong>
                                <?php echo e($fiduciario->fecha_nac_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Ciudad Aval:</strong>
                                <?php echo e($fiduciario->ciudad_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Correo Aval:</strong>
                                <?php echo e($fiduciario->correo_aval); ?>

                            </div>
                            <div class="form-group">
                                <strong>Foto Aval:</strong>
                                <?php echo e($fiduciario->foto_aval); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Financiera\resources\views/fiduciario/show.blade.php ENDPATH**/ ?>